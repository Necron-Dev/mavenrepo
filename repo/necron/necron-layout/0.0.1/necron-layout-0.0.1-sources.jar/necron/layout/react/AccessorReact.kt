package necron.layout.react

import necron.layout.util.Box
import kotlin.reflect.KMutableProperty0

class AccessorReact<T>(private val getter: () -> T, private val setter: (T) -> Unit) :
  BaseReact<T>(getter()),
  MutReact<T> {
  private var valueToSet: Box<T>? = null

  override fun set(value: T) {
    valueToSet = Box(value)
  }

  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {
    val last by this
    valueToSet?.run {
      valueToSet = null
      if (last != value) {
        setter(value)
        this@AccessorReact.setter(value)
      }
      return
    }
    val value = getter()
    if (last != value) {
      setter(value)
    }
  }
}

fun <T> useAccessor(getter: () -> T, setter: (T) -> Unit) = AccessorReact(getter, setter)

fun <T> useAccessor(property: KMutableProperty0<T>) = useAccessor(property::get, property::set)

val <T> KMutableProperty0<T>.accessor get() = useAccessor(this)
