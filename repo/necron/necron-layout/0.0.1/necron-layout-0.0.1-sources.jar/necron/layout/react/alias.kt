package necron.layout.react

typealias any = React<Any?>

typealias never = React<Nothing>

typealias bool = React<Boolean>

typealias float = React<Float>

typealias double = React<Double>

typealias byte = React<Byte>

typealias ubyte = React<UByte>

typealias short = React<Short>

typealias ushort = React<UShort>

typealias int = React<Int>

typealias uint = React<UInt>

typealias long = React<Long>

typealias ulong = React<ULong>

typealias char = React<Char>

typealias string = React<String>
