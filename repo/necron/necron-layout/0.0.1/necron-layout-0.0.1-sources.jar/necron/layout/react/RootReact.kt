package necron.layout.react

data object RootReact : RegistryReact<Nothing>() {
  private var _serial = -1L
  override val serial get() = _serial

  override fun get(): Nothing {
    throw ReactException("getting the value of RootReact is disallowed", dump = false)
  }

  override fun trigger(serial: Long, changed: Boolean): Boolean {
    try {
      globalReactStack.add(this)
      _serial = serial
      return triggerRegistry(serial, changed)
    } finally {
      globalReactStack.removeLast()
    }
  }
}

private var serial = 0L

fun triggerRoot() = RootReact.trigger(serial++, false)

fun syncRoot() = RootReact.sync()
