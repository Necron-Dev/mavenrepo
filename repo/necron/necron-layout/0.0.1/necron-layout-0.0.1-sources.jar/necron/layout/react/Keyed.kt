package necron.layout.react

data class Keyed<out T>(override val key: Any?, val value: T) : Key
