package necron.layout.react

val zero = 0.0.const

val half = 0.5.const

val unit = 1.0.const

val inf = Double.POSITIVE_INFINITY.const
