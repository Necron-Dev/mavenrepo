package necron.layout.react

abstract class BaseReact<out T>(private var value: T) : RegistryReact<T>() {
  private var dependencies: MutableSet<any>? = null
  private var dependenciesToSync: MutableSet<any>? = null

  private var registeredRoot = true
  private var triggered = -1
  private var needUpdate = false
  private var updateSerial = -1L

  private var _serial = -1L
  override val serial get() = _serial

  init {
    RootReact.register(this)
  }

  override fun get(): T {
    return value
  }

  protected abstract fun update(updating: Boolean, serial: Long, setter: (T) -> Unit)

  private fun raise(message: String): Nothing {
    throw ReactException(
      message +
        "\n  i am $this" +
        "\n  triggered $triggered" +
        "\n  dependencies $dependencies" +
        "\n  dependencies to sync $dependenciesToSync",
    )
  }

  override fun trigger(serial: Long, changed: Boolean): Boolean {
    try {
      var thisChanged = false
      globalReactStack.add(this)
      if (updateSerial != serial) {
        if (triggered != -1) {
          raise("trigger < degree, may be circular dependency or unmanaged (un)register")
        }
        updateSerial = serial
        needUpdate = false
        triggered = 0
      }
      if (triggered == -1) {
        raise("trigger > degree, may be unmanaged (un)register")
      }
      needUpdate = needUpdate || changed
      triggered++
      val deps = dependencies?.size ?: 1
      if (triggered > deps) {
        raise("triggered > degree (pre), this should not happen")
      }
      if (triggered == deps) {
        var value = value
        update(needUpdate, serial) {
          thisChanged = true
          value = it
        }
        if (thisChanged) {
          this.value = value
          _serial = serial
        }
        triggered = -1
        thisChanged = thisChanged or triggerRegistry(serial, thisChanged)
      }
      return thisChanged
    } finally {
      globalReactStack.removeLast()
    }
  }

  private fun createToSync(): MutableSet<any> {
    var dependencies = dependenciesToSync
    if (dependencies == null) {
      dependencies = this.dependencies?.toMutableSet() ?: []
      dependenciesToSync = dependencies
    }
    return dependencies
  }

  fun hookReact(react: any) {
    if (react.register(this)) {
      createToSync().add(react)
      if (registeredRoot) {
        RootReact.unregister(this)
        registeredRoot = false
      }
    }
  }

  fun unhookReact(react: any) {
    if (react.unregister(this)) {
      val toSync = createToSync()
      toSync.remove(react)
      if (toSync.isEmpty() && !registeredRoot) {
        RootReact.register(this)
        registeredRoot = true
      }
    }
  }

  override fun sync(): Boolean {
    var thisChanged = false
    dependenciesToSync?.let { deps ->
      dependencies = deps.takeIf { it.isNotEmpty() }
      dependenciesToSync = null
      thisChanged = true
    }
    return thisChanged or super.sync()
  }
}

fun <T : BaseReact<*>> T.hook(vararg reacts: any): T {
  reacts.forEach(::hookReact)
  return this
}

fun <T : BaseReact<*>> T.unhook(vararg reacts: any): T {
  reacts.forEach(::unhookReact)
  return this
}

fun <T : BaseReact<*>> T.hook(reacts: Iterable<any>): T {
  reacts.forEach(::hookReact)
  return this
}

fun <T : BaseReact<*>> T.unhook(reacts: Iterable<any>): T {
  reacts.forEach(::unhookReact)
  return this
}
