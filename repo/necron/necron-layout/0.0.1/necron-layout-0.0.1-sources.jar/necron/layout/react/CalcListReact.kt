package necron.layout.react

import java.util.*

class CalcListReact<out T : Key>(private val calculateList: () -> List<KeyConstructor<T>>) :
  BaseReact<List<T>>(calculateList().map { it.construct(it.key) }),
  ListReact<T> {
  override val operations: List<ListReact.Operation<T>>
    field = mutableListOf<ListReact.Operation<T>>()

  override fun update(updating: Boolean, serial: Long, setter: (List<T>) -> Unit) {
    if (!updating) return

    val list = LinkedList(get())
    val entries = calculateList()
    operations.clear()

    val _ = buildMap {
      entries.forEachIndexed { i, (key) ->
        if (put(key, i) != null) {
          throw ReactException("duplicate key $key")
        }
      }
      val indexes = mutableListOf<Int>()
      val iter = list.listIterator(list.size)
      while (iter.hasPrevious()) {
        if (iter.previous().key !in this) {
          indexes += iter.nextIndex()
          iter.remove()
        }
      }
      if (indexes.isNotEmpty()) {
        operations += ListReact.Remove(indexes.reversed())
      }
    }

    val _ = buildMap {
      list.forEachIndexed { i, value ->
        if (put(value.key, i) != null) {
          throw ReactException("duplicate key ${value.key}")
        }
      }
      // https://youtrack.jetbrains.com/issue/KT-86220/Name-based-destructuring-fails-in-double-nested-buildList-without-explicitly-specifying-generics
      val order: List<Int> = buildList {
        entries.forEach { (key) ->
          add(get(key) ?: return@forEach)
        }
      }
      if (order.withIndex().any { (index, value) -> index != value }) {
        operations += ListReact.Reorder(order)
        val arrayList = list.toList()
        list.clear()
        list.addAll(List(arrayList.size) { arrayList[order[it]] })
      }
    }

    val _ = buildMap {
      list.forEachIndexed { i, (key) ->
        if (put(key, i) != null) {
          throw ReactException("duplicate key $key")
        }
      }
      val insertEntries = mutableListOf<ListReact.Insert.Entry<T>>()
      val iter = list.listIterator(list.size)
      entries.reversed().forEach { (key, construct) ->
        if (get(key) == null) {
          val element = construct(key)
          insertEntries += ListReact.Insert.Entry(iter.nextIndex(), element)
          iter.add(element)
        }
        val _ = iter.previous()
      }
      if (insertEntries.isNotEmpty()) {
        operations += ListReact.Insert(insertEntries.reversed())
      }
    }

    setter(list.toList())
  }
}

fun <T : Key> useCalcList(calculateList: () -> List<KeyConstructor<T>>) =
  CalcListReact(calculateList)
