package necron.layout.react

val globalReactStack = mutableListOf<React<*>>()

class ReactException(message: String = "", cause: Throwable? = null, dump: Boolean = true) :
  Exception(message, cause) {
  val reactStack = globalReactStack.toList()
}
