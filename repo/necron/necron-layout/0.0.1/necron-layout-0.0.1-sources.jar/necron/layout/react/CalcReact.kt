package necron.layout.react

class CalcReact<out T>(private val calculate: () -> T) : BaseReact<T>(calculate()) {
  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {
    if (!updating) return
    val value = calculate()
    if (get() != value) {
      setter(value)
    }
  }
}

fun <T> useCalc(fn: () -> T) = CalcReact(fn)

inline fun <V, T> React<V>.calc(crossinline fn: (V) -> T): CalcReact<T> {
  return CalcReact { fn(this()) }.hook(this)
}

inline fun <V> React<V>.listen(
  crossinline initial: (V) -> Unit = {},
  crossinline changed: (V) -> Unit,
): CalcReact<Unit> {
  var first = true
  return CalcReact {
    if (first) {
      first = false
      initial(this())
    } else {
      changed(this())
    }
  }.hook(this)
}

inline fun <V> React<V>.listen(
  crossinline initial: (V) -> Unit = {},
  crossinline changed: (V, V) -> Unit,
): CalcReact<Unit> {
  var first = true
  var last = this()
  return CalcReact {
    if (first) {
      first = false
      initial(this())
    } else {
      changed(last, this()).also {
        last = this()
      }
    }
  }.hook(this)
}
