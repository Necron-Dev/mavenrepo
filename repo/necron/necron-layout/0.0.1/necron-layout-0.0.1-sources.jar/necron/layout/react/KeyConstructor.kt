package necron.layout.react

class KeyConstructor<out T>(override val key: Any?, val construct: (Any?) -> T) : Key
