package necron.layout.react

fun useTimer(interval: double, start: Double = 0.0, count: Int = -1): long {
  val intervalNs = interval.calc { (it * 1_000_000_000).toLong() }
  var last = NanoTime()
  var accumulator = -(start * 1_000_000_000).toLong()
  var serial = 0L
  var count = count
  return useAuto {
    if (count == 0) return@useAuto serial
    val time by NanoTime
    val int by intervalNs
    if (time - last >= 0) {
      accumulator += time - last
    }
    last = time
    if (accumulator >= int) {
      accumulator -= int
      if (count > 0) count--
      ++serial
    } else {
      serial
    }
  }
}
