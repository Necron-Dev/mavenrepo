package necron.layout.react

import kotlin.reflect.KProperty

interface React<out T> {
  val serial: Long

  fun get(): T

  fun trigger(serial: Long, changed: Boolean): Boolean

  fun sync(): Boolean

  fun register(react: React<*>): Boolean

  fun unregister(react: React<*>): Boolean

  fun attach(obj: Any?): Boolean

  fun detach(obj: Any?): Boolean
}

operator fun <T> React<T>.getValue(self: Any?, prop: KProperty<*>) = get()

operator fun <T> React<T>.invoke() = get()

fun <S : React<T>, T> S.bind(vararg objects: Any?) = apply { objects.forEach(::attach) }

fun <S : React<T>, T> S.unbind(vararg objects: Any?) = apply { objects.forEach(::detach) }
