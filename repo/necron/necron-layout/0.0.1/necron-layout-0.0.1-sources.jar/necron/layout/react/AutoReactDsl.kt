package necron.layout.react

import kotlin.reflect.KProperty

class AutoReactDsl(private val dependencies: MutableSet<React<*>>) {
  operator fun <T> React<T>.provideDelegate(self: Any?, prop: KProperty<*>): React<T> {
    dependencies += this
    return this
  }

  operator fun <T> MutReact<T>.provideDelegate(self: Any?, prop: KProperty<*>): MutReact<T> {
    dependencies += this
    return this
  }

  operator fun <T> React<T>.invoke(): T {
    dependencies += this
    return get()
  }

  fun listen(vararg reacts: React<*>) {
    dependencies += reacts
  }
}

inline fun <T> useAuto(crossinline fn: AutoReactDsl.() -> T): CalcReact<T> {
  var lastDependencies = mutableSetOf<React<*>>()
  var calcReact: CalcReact<T>? = null
  calcReact = CalcReact {
    val dependencies = mutableSetOf<React<*>>()
    val dsl = AutoReactDsl(dependencies)
    val value = dsl.fn()
    calcReact?.apply {
      unhook(lastDependencies - dependencies)
      hook(dependencies - lastDependencies)
    }
    lastDependencies = dependencies
    value
  }.hook(lastDependencies)
  return calcReact
}
