package necron.layout.react

class PollReact<out T>(private val calculate: () -> T) : BaseReact<T>(calculate()) {
  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {
    val value = calculate()
    if (get() != value) {
      setter(value)
    }
  }
}

fun <T> usePoll(fn: () -> T) = PollReact(fn)
