package necron.layout.react

private val updater = useUpdater()

data object NanoTime : long by useCalc({ System.nanoTime() }).hook(updater)

fun updateNanoTime() {
  updater.update()
}
