package necron.layout.react

class UpdaterReact : BaseReact<Unit>(Unit) {
  private var update = false

  fun update() {
    update = true
  }

  override fun update(updating: Boolean, serial: Long, setter: (Unit) -> Unit) {
    if (!update) return
    update = false
    setter(Unit)
  }
}

fun useUpdater() = UpdaterReact()
