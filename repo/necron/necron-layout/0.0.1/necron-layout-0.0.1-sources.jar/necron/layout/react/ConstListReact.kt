package necron.layout.react

class ConstListReact<out T>(list: List<T>) :
  BaseReact<List<T>>(list),
  ListReact<T> {
  override fun update(updating: Boolean, serial: Long, setter: (List<T>) -> Unit) {
  }

  override val operations = listOf<ListReact.Operation<T>>()
}

inline fun <T> useConstList(fn: () -> List<T>): ConstListReact<T> {
  return ConstListReact(fn())
}

val <T> List<T>.constList get() = useConstList { this }

val emptyConstList = listOf<Nothing>().constList
