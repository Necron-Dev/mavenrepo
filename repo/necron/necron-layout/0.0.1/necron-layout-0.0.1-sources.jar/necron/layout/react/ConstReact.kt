package necron.layout.react

class ConstReact<out T>(value: T) : BaseReact<T>(value) {
  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {}
}

inline fun <T> useConst(fn: () -> T): ConstReact<T> {
  return ConstReact(fn())
}

val <T> T.const get() = useConst { this }
