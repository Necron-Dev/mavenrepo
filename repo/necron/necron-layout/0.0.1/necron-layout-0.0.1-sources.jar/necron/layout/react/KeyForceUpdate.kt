package necron.layout.react

data class KeyForceUpdate<out T : Key>(val value: T) : Key by value {
  override fun equals(other: Any?): Boolean {
    return false
  }

  override fun hashCode(): Int {
    return super.hashCode()
  }
}
