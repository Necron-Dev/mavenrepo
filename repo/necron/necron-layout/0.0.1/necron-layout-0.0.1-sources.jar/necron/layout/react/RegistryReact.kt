package necron.layout.react

import java.util.*

abstract class RegistryReact<out T> : AttachableReact<T>() {
  private var registry: WeakHashMap<any, Unit>? = null

  private var registryToSync: WeakHashMap<any, Unit>? = null

  private var isSyncing = false

  protected fun triggerRegistry(serial: Long, changed: Boolean): Boolean {
    var childrenChanged = false
    registry?.keys?.toMutableList()?.forEach {
      childrenChanged = childrenChanged or it.trigger(serial, changed)
    }
    return childrenChanged
  }

  private fun createToSync(): WeakHashMap<any, Unit> {
    var registry = registryToSync
    if (registry == null) {
      registry = this.registry?.let { WeakHashMap(it) } ?: WeakHashMap()
      registryToSync = registry
    }
    return registry
  }

  override fun register(react: any): Boolean {
    return createToSync().put(react, Unit) == null
  }

  override fun unregister(react: any): Boolean {
    return createToSync().remove(react) != null
  }

  override fun sync(): Boolean {
    try {
      globalReactStack += this
      if (isSyncing) {
        throw ReactException("sync is called recursively")
      }
      isSyncing = true
      var thisChanged = false
      registryToSync?.let { reg ->
        registry = reg.takeIf { it.isNotEmpty() }
        registryToSync = null
        thisChanged = true
      }
      registry?.keys?.toMutableList()?.forEach {
        thisChanged = thisChanged or it.sync()
      }
      return thisChanged
    } finally {
      globalReactStack.removeLast()
      isSyncing = false
    }
  }
}
