package necron.layout.react

interface ListReact<out T> : React<List<T>> {
  val operations: List<Operation<T>>

  sealed interface Operation<out T>

  data class Insert<out T>(val entries: List<Entry<T>>) : Operation<T> {
    data class Entry<out T>(val index: Int, val value: T)
  }

  data class Reorder(val order: List<Int>) : Operation<Nothing>

  data class Remove(val indexes: List<Int>) : Operation<Nothing>

  data object Clear : Operation<Nothing>
}
