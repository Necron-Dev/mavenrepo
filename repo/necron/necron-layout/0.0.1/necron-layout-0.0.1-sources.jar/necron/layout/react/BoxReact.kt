package necron.layout.react

class BoxReact<T>(private var value: T) :
  BaseReact<T>(value),
  MutReact<T> {
  private var update = false

  override fun set(value: T) {
    this.value = value
    update = true
  }

  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {
    if (!update) return
    update = false
    val value = value
    if (get() != value) {
      setter(value)
    }
  }
}

inline fun <T> useBox(fn: () -> T): BoxReact<T> {
  return BoxReact(fn())
}

val <T> T.box get() = useBox { this }
