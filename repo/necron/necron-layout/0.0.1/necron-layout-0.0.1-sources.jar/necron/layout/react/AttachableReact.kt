package necron.layout.react

abstract class AttachableReact<out T> : React<T> {
  private val bound = mutableSetOf<Any?>()

  override fun attach(obj: Any?) = bound.add(obj)

  override fun detach(obj: Any?) = bound.remove(obj)
}
