package necron.layout.react

interface Key {
  val key: Any?
}
