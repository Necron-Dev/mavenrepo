package necron.layout.react

class SubMutReact<T>(
  private var parent: MutReact<*>,
  private var getter: () -> T,
  private var setter: (T) -> Unit,
) : BaseReact<T>(getter()),
  MutReact<T> {
  private var value = get()

  private var updateParent = false
  private var updateValue = false

  init {
    hook(parent)
  }

  override fun set(value: T) {
    this.value = value
    updateValue = true
  }

  fun <V> setParent(parent: MutReact<V>, transform: (V) -> T, reverse: (T) -> V) {
    unhook(this.parent)
    this.parent = parent
    hook(parent)
    getter = { transform(parent()) }
    setter = { parent of reverse(it) }
    updateParent = true
    updateValue = false
  }

  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {
    if (!updateParent && !updateValue && (!updating || serial != parent.serial)) return
    val last by this
    if (updateValue) {
      if (last != value) {
        setter(value)
        this.setter(value)
      }
    } else {
      val value = getter()
      if (last != value) {
        setter(value)
        this.value = value
      }
    }
    updateValue = false
    updateParent = false
  }
}

fun <T> SubMutReact<T>.setParent(parent: MutReact<T>) {
  setParent(parent, { it }, { it })
}

inline fun <V, T> useSubMut(
  parent: MutReact<V>,
  crossinline transform: (V) -> T,
  crossinline reverse: (T) -> V,
) = SubMutReact(parent, { transform(parent()) }, { parent of reverse(it) })

fun <T> useSubMut(parent: MutReact<T>) = useSubMut(parent, { it }, { it })

inline fun <V, T> MutReact<V>.subMut(
  crossinline transform: (V) -> T,
  crossinline reverse: (T) -> V,
) = useSubMut(this, transform, reverse)

val <T> MutReact<T>.subMut get() = useSubMut(this)
