package necron.layout.react

import java.util.*

class SubListReact<T>(
  private var parent: ListReact<*>,
  private var getter: (Int) -> T,
  private var operationEntries: (Int) -> ListReact.Insert<T>,
) : BaseReact<List<T>>(List(parent().size, getter)),
  ListReact<T> {
  override val operations: List<ListReact.Operation<T>>
    field = mutableListOf<ListReact.Operation<T>>()

  private var update = false

  init {
    hook(parent)
  }

  fun <V> setParent(parent: ListReact<V>, transform: (V) -> T) {
    unhook(this.parent)
    this.parent = parent
    hook(parent)
    getter = { transform(parent()[it]) }
    operationEntries = { i ->
      ListReact.Insert(
        (parent.operations[i] as ListReact.Insert).entries.map {
          ListReact.Insert.Entry(it.index, transform(it.value))
        },
      )
    }
    update = true
  }

  override fun update(updating: Boolean, serial: Long, setter: (List<T>) -> Unit) {
    if (!update && (!updating || serial != parent.serial)) return
    if (update) {
      update = false
      val list = List(parent().size, getter)
      setter(list)
      operations.clear()
      operations += ListReact.Clear
      operations += ListReact.Insert(list.map { v -> ListReact.Insert.Entry(0, v) })
    } else {
      val list = LinkedList(get())
      operations.clear()
      parent.operations.forEachIndexed { index, operation ->
        when (operation) {
          is ListReact.Clear -> {
            operations += operation
            list.clear()
          }

          is ListReact.Insert -> {
            val operation = operationEntries(index)
            operations += operation
            val entries = operation.entries.toMutableList()
            val iter = list.listIterator(list.size)
            while (entries.isNotEmpty()) {
              val last = entries.last()
              if (iter.nextIndex() == last.index) {
                iter.add(last.value)
                entries.removeLast()
              }
              val _ = iter.previous()
            }
          }

          is ListReact.Remove -> {
            operations += operation
            val indexes = operation.indexes.toMutableList()
            val iter = list.listIterator(list.size)
            while (indexes.isNotEmpty()) {
              if (iter.nextIndex() == indexes.last()) {
                iter.remove()
                indexes.removeLast()
              } else {
                val _ = iter.previous()
              }
            }
          }

          is ListReact.Reorder -> {
            operations += operation
            val arrayList = list.toList()
            list.clear()
            list.addAll(List(arrayList.size) { arrayList[operation.order[it]] })
          }
        }
      }
      setter(list.toList())
    }
  }
}

fun <T> SubListReact<T>.setParent(parent: ListReact<T>) {
  setParent(parent) { it }
}

inline fun <V, T> useSubList(parent: ListReact<V>, crossinline transform: (V) -> T) = SubListReact(
  parent,
  { transform(parent()[it]) },
  { i ->
    ListReact.Insert(
      (parent.operations[i] as ListReact.Insert).entries.map {
        ListReact.Insert.Entry(it.index, transform(it.value))
      },
    )
  },
)

fun <T> useSubList(parent: ListReact<T>) = useSubList(parent) { it }

inline fun <V, T> ListReact<V>.subList(crossinline transform: (V) -> T) =
  useSubList(this, transform)

val <T> ListReact<T>.subList get() = useSubList(this)
