package necron.layout.react

class SubReact<T>(private var parent: React<*>, private var fn: () -> T) : BaseReact<T>(fn()) {
  private var update = false

  init {
    hook(parent)
  }

  fun <V> setParent(parent: React<V>, transform: (V) -> T) {
    unhook(this.parent)
    this.parent = parent
    hook(parent)
    fn = { transform(parent()) }
    update = true
  }

  override fun update(updating: Boolean, serial: Long, setter: (T) -> Unit) {
    if (!update && (!updating || serial != parent.serial)) return
    update = false
    val value = fn()
    if (get() != value) {
      setter(value)
    }
  }
}

fun <T> SubReact<T>.setParent(parent: React<T>) {
  setParent(parent) { it }
}

inline fun <V, T> useSub(parent: React<V>, crossinline transform: (V) -> T) =
  SubReact(parent) { transform(parent()) }

fun <T> useSub(parent: React<T>) = useSub(parent) { it }

inline fun <V, T> React<V>.sub(crossinline transform: (V) -> T) = useSub(this, transform)

val <T> React<T>.sub get() = useSub(this)
