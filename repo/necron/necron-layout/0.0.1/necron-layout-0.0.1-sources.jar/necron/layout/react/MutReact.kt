package necron.layout.react

import kotlin.reflect.KProperty

interface MutReact<T> : React<T> {
  fun set(value: T)
}

operator fun <T> MutReact<T>.setValue(self: Any?, prop: KProperty<*>, value: T) {
  set(value)
}

operator fun <T> MutReact<T>.invoke(value: T) {
  set(value)
}

infix fun <T> MutReact<T>.of(value: T) {
  set(value)
}
