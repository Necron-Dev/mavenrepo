package necron.layout.react

data class ForceUpdate<out T>(val value: T) {
  override fun equals(other: Any?): Boolean {
    return false
  }

  override fun hashCode(): Int {
    return super.hashCode()
  }
}
