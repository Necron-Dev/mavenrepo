package necron.layout.util

val pass get() = Unit
