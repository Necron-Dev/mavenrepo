package necron.layout.util

val <T> T.provider: () -> T get() = { this }
