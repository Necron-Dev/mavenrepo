package necron.layout.util

data class Box<out T>(val value: T)
