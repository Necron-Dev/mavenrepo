package necron.layout.util

interface InvokeAsRun

inline operator fun <T : InvokeAsRun, R> T.invoke(fn: T.() -> R): R = run(fn)
