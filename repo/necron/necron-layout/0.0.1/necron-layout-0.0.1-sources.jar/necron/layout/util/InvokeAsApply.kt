package necron.layout.util

interface InvokeAsApply

inline operator fun <T : InvokeAsApply> T.invoke(fn: T.() -> Unit): T = apply(fn)
