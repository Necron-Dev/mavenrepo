package necron.layout.util

interface Self<T> {
  val self: T
}
