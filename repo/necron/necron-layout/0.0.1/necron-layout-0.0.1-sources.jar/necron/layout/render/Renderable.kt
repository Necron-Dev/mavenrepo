package necron.layout.render

import necron.layout.vector.Transformable

interface Renderable<T : Renderable<T>> : Transformable<T> {
  fun opacify(factor: Double): T
}
