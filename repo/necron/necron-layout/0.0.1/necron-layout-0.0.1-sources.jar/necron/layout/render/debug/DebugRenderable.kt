package necron.layout.render.debug

import necron.layout.render.Renderable

interface DebugRenderable<T : DebugRenderable<T>> : Renderable<T>
