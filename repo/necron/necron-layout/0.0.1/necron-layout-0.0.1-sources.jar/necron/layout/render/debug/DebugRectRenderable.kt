package necron.layout.render.debug

import necron.layout.vector.Vec
import necron.layout.vector.plus
import necron.layout.vector.scale

data class DebugRectRenderable(val type: Type, val nw: Vec, val se: Vec) :
  DebugRenderable<DebugRectRenderable> {
  override val self get() = this

  override fun opacify(factor: Double) = this

  override fun translate(vec: Vec) = copy(nw = nw + vec, se = se + vec)

  override fun scale(origin: Vec, factor: Double) = copy(
    nw = nw.scale(origin, factor),
    se = se.scale(origin, factor),
  )

  enum class Type {
    Outer,
    Inner,
  }
}
