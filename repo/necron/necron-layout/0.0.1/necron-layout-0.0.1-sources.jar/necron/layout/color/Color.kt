package necron.layout.color

import necron.layout.react.React

data class Color(val a: Double, val r: Double, val g: Double, val b: Double) {
  val int = ((a * 255.0).toInt().coerceIn(0..255) shl 24) or
    ((r * 255.0).toInt().coerceIn(0..255) shl 16) or
    ((g * 255.0).toInt().coerceIn(0..255) shl 8) or
    ((b * 255.0).toInt().coerceIn(0..255))

  val isIntTransparent = int shr 24 == 0
}

typealias color = React<Color>

fun rgb(r: Double, g: Double = r, b: Double = r) = Color(1.0, r, g, b)

fun argb(a: Double, r: Double, g: Double = r, b: Double = r) = Color(a, r, g, b)

fun rgbInt(c: Long) = rgb(
  (c shr 16 and 0xFF) / 255.0,
  (c shr 8 and 0xFF) / 255.0,
  (c and 0xFF) / 255.0,
)

fun argbInt(c: Long) = argb(
  (c shr 24 and 0xFF) / 255.0,
  (c shr 16 and 0xFF) / 255.0,
  (c shr 8 and 0xFF) / 255.0,
  (c and 0xFF) / 255.0,
)

infix fun Color.opacify(factor: Double) = copy(a = a * factor)

val Color.transparent get() = copy(a = 0.0)

val blackTransparent = argb(0.0, 0.0)
val whiteTransparent = argb(0.0, 1.0)
val black = rgb(0.0)
val white = rgb(1.0)
