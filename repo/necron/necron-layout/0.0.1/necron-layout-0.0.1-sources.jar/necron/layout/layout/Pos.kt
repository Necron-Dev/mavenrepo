package necron.layout.layout

import necron.layout.react.*

sealed interface Pos

data object Auto : Pos

data class Fixed(val position: double) : Pos

data class Anchor(val relative: double, val anchor: double, val offset: double) : Pos

data class Align(val relative: double, val anchor: double, val offset: double) : Pos

val auto = Auto

val double.fixed get() = Fixed(this)

val zeroPos = zero.fixed

fun anchor(relative: double, anchor: double = relative, offset: double = zero): Anchor {
  return Anchor(relative, anchor, offset)
}

fun anchor(relative: Double, anchor: Double = relative, offset: Double = 0.0): Anchor {
  return anchor(relative.const, anchor.const, offset.const)
}

fun anchorLL(offset: double = zero) = anchor(zero, zero, offset)

fun anchorLL(offset: Double) = anchorLL(offset.const)

val anchorLL = anchorLL()

fun anchorLC(offset: double = zero) = anchor(zero, half, offset)

fun anchorLC(offset: Double) = anchorLC(offset.const)

val anchorLC = anchorLC()

fun anchorLR(offset: double = zero) = anchor(zero, unit, offset)

fun anchorLR(offset: Double) = anchorLR(offset.const)

val anchorLR = anchorLR()

fun anchorCL(offset: double = zero) = anchor(half, zero, offset)

fun anchorCL(offset: Double) = anchorCL(offset.const)

val anchorCL = anchorCL()

fun anchorCC(offset: double = zero) = anchor(half, half, offset)

fun anchorCC(offset: Double) = anchorCC(offset.const)

val anchorCC = anchorCC()

fun anchorCR(offset: double = zero) = anchor(half, unit, offset)

fun anchorCR(offset: Double) = anchorCR(offset.const)

val anchorCR = anchorCR()

fun anchorRL(offset: double = zero) = anchor(unit, zero, offset)

fun anchorRL(offset: Double) = anchorRL(offset.const)

val anchorRL = anchorRL()

fun anchorRC(offset: double = zero) = anchor(unit, half, offset)

fun anchorRC(offset: Double) = anchorRC(offset.const)

val anchorRC = anchorRC()

fun anchorRR(offset: double = zero) = anchor(unit, unit, offset)

fun anchorRR(offset: Double) = anchorRR(offset.const)

val anchorRR = anchorRR()

fun align(relative: double, anchor: double = relative, offset: double = zero): Align {
  return Align(relative, anchor, offset)
}

fun align(relative: Double, anchor: Double = relative, offset: Double = 0.0): Align {
  return align(relative.const, anchor.const, offset.const)
}

fun alignLL(offset: double = zero) = align(zero, zero, offset)

fun alignLL(offset: Double) = alignLL(offset.const)

val alignLL = alignLL()

fun alignLC(offset: double = zero) = align(zero, half, offset)

fun alignLC(offset: Double) = alignLC(offset.const)

val alignLC = alignLC()

fun alignLR(offset: double = zero) = align(zero, unit, offset)

fun alignLR(offset: Double) = alignLR(offset.const)

val alignLR = alignLR()

fun alignCL(offset: double = zero) = align(half, zero, offset)

fun alignCL(offset: Double) = alignCL(offset.const)

val alignCL = alignCL()

fun alignCC(offset: double = zero) = align(half, half, offset)

fun alignCC(offset: Double) = alignCC(offset.const)

val alignCC = alignCC()

fun alignCR(offset: double = zero) = align(half, unit, offset)

fun alignCR(offset: Double) = alignCR(offset.const)

val alignCR = alignCR()

fun alignRL(offset: double = zero) = align(unit, zero, offset)

fun alignRL(offset: Double) = alignRL(offset.const)

val alignRL = alignRL()

fun alignRC(offset: double = zero) = align(unit, half, offset)

fun alignRC(offset: Double) = alignRC(offset.const)

val alignRC = alignRC()

fun alignRR(offset: double = zero) = align(unit, unit, offset)

fun alignRR(offset: Double) = alignRR(offset.const)

val alignRR = alignRR()
