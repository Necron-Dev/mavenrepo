package necron.layout.layout

import necron.layout.react.*
import necron.layout.widget.ChildrenDsl
import necron.layout.widget.Container

sealed interface Dim {
  fun create(minimum: () -> double, space: () -> double, length: () -> double): double

  fun create(minimum: () -> double): double
}

data class Px(val value: double) : Dim {
  override fun create(minimum: () -> double, space: () -> double, length: () -> double) = value

  override fun create(minimum: () -> double) = value
}

data class Dep(val value: double) : Dim {
  override fun create(minimum: () -> double, space: () -> double, length: () -> double) = value

  override fun create(minimum: () -> double) = zero
}

data class Flex(val value: double) : Dim {
  override fun create(minimum: () -> double, space: () -> double, length: () -> double) =
    useAuto { space()() * value() }

  override fun create(minimum: () -> double) = zero
}

data class Ratio(val value: double) : Dim {
  override fun create(minimum: () -> double, space: () -> double, length: () -> double) =
    useAuto { length()() * value() }

  override fun create(minimum: () -> double) = zero
}

data class Min(val value: double) : Dim {
  override fun create(minimum: () -> double, space: () -> double, length: () -> double) =
    create(minimum)

  override fun create(minimum: () -> double) = useAuto { minimum()() * value() }
}

data class Op(val dims: List<Dim>, val fn: AutoReactDsl.(List<double>) -> Double) : Dim {
  override fun create(minimum: () -> double, space: () -> double, length: () -> double): double {
    val reacts = dims.map { dp -> dp.create(minimum, space, length) }
    return useAuto { fn(reacts) }
  }

  override fun create(minimum: () -> double): double {
    val reacts = dims.map { dp -> dp.create(minimum) }
    return useAuto { fn(reacts) }
  }
}

val double.px get() = Px(this)

val Double.px get() = const.px

val zeroDim = zero.px

val double.min get() = Min(this)

val Double.min get() = const.min

val min = unit.min

val double.dep get() = Dep(this)

val Double.dep get() = const.dep

context(dsl: ChildrenDsl<Container>)
val double.flex get() = Flex(this)

context(dsl: ChildrenDsl<Container>)
val Double.flex get() = const.flex

context(dsl: ChildrenDsl<Container>)
val flex get() = unit.flex

context(dsl: ChildrenDsl<Container>)
val double.ratio get() = Ratio(this)

context(dsl: ChildrenDsl<Container>)
val Double.ratio get() = const.ratio

context(dsl: ChildrenDsl<Container>)
val ratio get() = unit.ratio

fun op(vararg dims: Dim, fn: AutoReactDsl.(List<double>) -> Double) = Op(dims.toList(), fn)

context(dsl: ChildrenDsl<Container>)
val double.widthFlex get() = useAuto { this@widthFlex() * dsl.parent.xSpace() }.px

context(dsl: ChildrenDsl<Container>)
val double.heightFlex get() = useAuto { this@heightFlex() * dsl.parent.ySpace() }.px

context(dsl: ChildrenDsl<Container>)
val double.widthRatio get() = useAuto { this@widthRatio() * dsl.parent.width() }.px

context(dsl: ChildrenDsl<Container>)
val double.heightRatio get() = useAuto { this@heightRatio() * dsl.parent.height() }.px

context(dsl: ChildrenDsl<Container>)
val widthFlex get() = dsl.parent.xSpace.px

context(dsl: ChildrenDsl<Container>)
val heightFlex get() = dsl.parent.ySpace.px

context(dsl: ChildrenDsl<Container>)
val widthRatio get() = dsl.parent.width.px

context(dsl: ChildrenDsl<Container>)
val heightRatio get() = dsl.parent.height.px

context(_: ChildrenDsl<Container>)
val Double.widthFlex get() = const.widthFlex

context(_: ChildrenDsl<Container>)
val Double.heightFlex get() = const.heightFlex

context(_: ChildrenDsl<Container>)
val Double.widthRatio get() = const.widthRatio

context(_: ChildrenDsl<Container>)
val Double.heightRatio get() = const.heightRatio
