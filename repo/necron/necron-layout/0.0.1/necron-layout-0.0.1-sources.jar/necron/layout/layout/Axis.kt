package necron.layout.layout

enum class Axis {
  X,
  Y,
}
