package necron.layout.layout

import necron.layout.react.const
import necron.layout.react.double
import necron.layout.react.zero

data class Pad(val top: double, val right: double, val bottom: double, val left: double)

fun pad(top: double, right: double = top, bottom: double = top, left: double = right) =
  Pad(top, right, bottom, left)

fun pad(top: Double, right: Double = top, bottom: Double = top, left: Double = right) =
  pad(top.const, right.const, bottom.const, left.const)

val zeroPad = pad(zero)

fun Pad.select(axis: Axis) = when (axis) {
  X -> left to right
  Y -> top to bottom
}
