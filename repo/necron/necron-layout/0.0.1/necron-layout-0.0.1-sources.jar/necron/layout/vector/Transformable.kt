package necron.layout.vector

import necron.layout.util.Self

interface Transformable<T> : Self<T> {
  fun translate(vec: Vec): T

  fun scale(origin: Vec, factor: Double): T
}
