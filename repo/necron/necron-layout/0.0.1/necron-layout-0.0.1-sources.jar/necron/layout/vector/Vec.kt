package necron.layout.vector

data class Vec(val x: Double, val y: Double)

infix fun Double.vec(other: Double) = Vec(this, other)

val zeroVec = 0.0 vec 0.0

operator fun Vec.unaryPlus() = this

operator fun Vec.unaryMinus() = -x vec -y

operator fun Vec.plus(v: Vec) = x + v.x vec y + v.y

operator fun Vec.minus(v: Vec) = x - v.x vec y - v.y

infix fun Vec.dot(v: Vec) = x * v.x + y * v.y

operator fun Vec.times(double: Double) = x * double vec y * double

operator fun Vec.div(double: Double) = x / double vec y / double

operator fun Double.times(v: Vec) = v * this

fun Vec.scale(origin: Vec, factor: Double) = origin + (this - origin) * factor
