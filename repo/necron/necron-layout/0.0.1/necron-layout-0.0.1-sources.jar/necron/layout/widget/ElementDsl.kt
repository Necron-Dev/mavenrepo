package necron.layout.widget

import necron.layout.backend.Backend
import necron.layout.style.Style
import kotlin.reflect.KClass

private val SENTINEL = Any()

abstract class ElementDsl<TParent : ChildrenDsl<*>, TSpec : Element.Spec>(
  val type: KClass<out TSpec>,
  val constructSpec: () -> TSpec,
) {
  inner class Tagged(val tags: List<*>) {
    context(backend: Backend, dsl: TParent, style: Style)
    operator fun invoke(key: Any? = SENTINEL, configure: TSpec.() -> Unit) {
      invoke(key, tags, configure)
    }
  }

  operator fun get(vararg tags: Any?) = Tagged(tags.toList())

  context(backend: Backend, dsl: TParent, style: Style)
  operator fun invoke(
    key: Any? = SENTINEL,
    tags: List<*> = listOf<Nothing>(),
    configure: TSpec.() -> Unit,
  ) {
    val key = if (key === SENTINEL) configure::class else key
    dsl.add(key) {
      val spec = constructSpec().initialized()
      spec["key"] = key
      spec["parent"] = dsl.parent
      spec["backend"] = backend
      spec["spec"] = type
      spec["style"] = style
      spec["tag"] = tags
      style.pre.forEach { it.transform(spec) }
      spec.configure()
      style.post.forEach { it.transform(spec) }
      new(spec)
    }
  }

  abstract fun new(spec: TSpec): Element
}
