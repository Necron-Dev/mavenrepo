package necron.layout.widget.container

import necron.layout.event.Event
import necron.layout.event.RenderEvent
import necron.layout.layout.*
import necron.layout.react.*
import necron.layout.render.debug.DebugRectRenderable
import necron.layout.style.Style
import necron.layout.vector.vec
import necron.layout.widget.*
import necron.layout.widget.element.Node

class Div private constructor(
  style: Style,
  private val delegatedConstructor: (SubListReact<Element>) -> Node,
  private val pad: Pad,
  axis: Axis,
  childrenDsl: Children<Div>,
  override val children: SubListReact<Element> = emptyConstList.subList,
  private val delegated: Node = delegatedConstructor(children)
) : Element by delegated,
  Container {
  val backend by delegated::backend
  override val xSpace = createSpace(children, Axis.X, axis == Axis.X, width, pad)
  override val ySpace = createSpace(children, Axis.Y, axis == Axis.Y, height, pad)

  init {
    children.setParent(createChildren(backend, this, style, childrenDsl))
  }

  private val _x = setupPosition(children, Axis.X, axis == Axis.X, width, pad, xSpace)
  private val _y = setupPosition(children, Axis.Y, axis == Axis.Y, height, pad, ySpace)

  override fun dispatch(event: Event, handled: Boolean): Boolean {
    when (event) {
      is RenderEvent -> {
        if (backend.debugMode) {
          event(
            DebugRectRenderable(
              DebugRectRenderable.Type.Inner,
              pad.left() vec pad.top(),
              width() - pad.right() vec height() - pad.bottom(),
            ),
          )
        }
      }
    }

    return delegated.dispatch(event, handled) or super.dispatch(event, handled)
  }

  interface Spec : Node.Spec, Container.Spec<Div> {
    override fun init() {
      super<Node.Spec>.init()
      super<Container.Spec>.init()
      set pad zeroPad
    }
  }

  class Config : MapSpec(), Spec

  companion object : ElementDsl<ChildrenDsl<*>, Spec>(Spec::class, ::Config) {
    private fun minimum(
      children: ListReact<Element>,
      axis: Axis,
      major: Boolean,
      pad: Pad,
    ): () -> double = lazy {
      val [l, r] = pad.select(axis)
      if (major) {
        useAuto {
          children().sumOf { it.selectLengthIndependent(axis)() } + l() + r()
        }
      } else {
        useAuto {
          (children().maxOfOrNull { it.selectLengthIndependent(axis)() } ?: 0.0) + l() + r()
        }
      }
    }::value

    private fun createDimIndependent(
      children: ListReact<Element>,
      axis: Axis,
      major: Boolean,
      dim: Dim,
      pad: Pad,
    ) = dim.create(minimum(children, axis, major, pad))

    private fun createSpace(
      children: ListReact<Element>,
      axis: Axis,
      major: Boolean,
      length: double,
      pad: Pad,
    ): double {
      val [l, r] = pad.select(axis)
      return if (major) {
        useAuto {
          length() - children().sumOf { it.selectLengthIndependent(axis)() } - l() - r()
        }
      } else {
        useAuto {
          length() -
            (children().maxOfOrNull { it.selectLengthIndependent(axis)() } ?: 0.0) - l() - r()
        }
      }
    }

    private fun setupPosition(
      children: ListReact<Element>,
      axis: Axis,
      major: Boolean,
      length: double,
      pad: Pad,
      space: double,
    ): any = if (major) {
      val boxes = children.subList { child ->
        when (val pos = child.selectPos(axis)) {
          is Fixed -> {
            child.selectPosition(axis).setParent(pos.position)
            null
          }

          Auto -> {
            val box = 0.0.box
            child.selectPosition(axis).setParent(box)
            child.selectLength(axis) to box
          }

          is Anchor -> {
            setupAnchor(axis, pos, length, child)
            null
          }

          is Align -> {
            setupAlign(axis, pos, space, pad, child)
            null
          }
        }
      }
      val padStart = pad.select(axis).first
      useAuto {
        var pos = padStart()
        boxes().filterNotNull().forEach { [childLength, box] ->
          box(pos)
          pos += childLength()
        }
      }
    } else {
      children.subList { child ->
        when (val pos = child.selectPos(axis)) {
          is Fixed -> child.selectPosition(axis).setParent(pos.position)

          Auto -> throw IllegalArgumentException("auto is disallowed in cross axis")

          is Anchor -> setupAnchor(axis, pos, length, child)

          is Align -> setupAlign(axis, pos, space, pad, child)
        }
      }
    }

    private fun createAnchor(
      anchor: Anchor,
      parent: double,
      element: double
    ) = useAuto {
      anchor.relative() * parent() - anchor.anchor() * element() + anchor.offset()
    }

    private fun setupAnchor(
      axis: Axis,
      anchor: Anchor,
      parent: double,
      element: Element
    ) {
      element
        .selectPosition(axis)
        .setParent(createAnchor(anchor, parent, element.selectLength(axis)))
    }

    private fun createAlign(
      anchor: Align,
      parent: double,
      padStart: double,
      element: double
    ) = useAuto {
      anchor.relative() * parent() - anchor.anchor() * element() + anchor.offset() + padStart()
    }

    private fun setupAlign(
      axis: Axis,
      anchor: Align,
      parent: double,
      pad: Pad,
      element: Element
    ) {
      element
        .selectPosition(axis)
        .setParent(createAlign(anchor, parent, pad.select(axis).first, element.selectLength(axis)))
    }

    override fun new(spec: Spec): Div {
      val axis: Axis by spec
      val pad: Pad by spec
      return Div(
        spec[spec::style],
        { children ->
          Node.new(
            spec,
            minimum(children, Axis.X, axis == Axis.X, pad),
            minimum(children, Axis.Y, axis == Axis.Y, pad),
            createDimIndependent(children, Axis.X, axis == Axis.X, spec[spec::width], pad),
            createDimIndependent(children, Axis.Y, axis == Axis.Y, spec[spec::height], pad),
          )
        },
        pad,
        axis,
        spec[spec::children]
      )
    }
  }
}

infix fun <T : Div.Spec> T.pad(it: Pad) = put("pad", it)
infix fun <T : Div.Spec> T.p(it: Pad) = pad(it)
infix fun <T : Div.Spec> T.axis(it: Axis) = put("axis", it)
infix fun <T : Div.Spec> T.a(it: Axis) = axis(it)
