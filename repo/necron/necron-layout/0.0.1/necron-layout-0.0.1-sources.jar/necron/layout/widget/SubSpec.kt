package necron.layout.widget

open class SubSpec(private val spec: Element.Spec, private val prefix: String) : Element.Spec {
  override fun <T> get(key: String): T = spec[prefix + key]

  override fun set(key: String, value: Any?) {
    spec[prefix + key] = value
  }

  override val specEntries
    get() = spec.specEntries.mapNotNull { [key, value] ->
      if (key.startsWith(prefix)) {
        key.removePrefix(prefix) to value
      } else {
        null
      }
    }
}
