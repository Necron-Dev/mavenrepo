package necron.layout.widget

import necron.layout.backend.Backend
import necron.layout.event.Event
import necron.layout.layout.Axis
import necron.layout.layout.Dim
import necron.layout.layout.Pos
import necron.layout.react.Key
import necron.layout.react.SubReact
import necron.layout.react.double
import necron.layout.util.InvokeAsRun
import kotlin.reflect.KClass
import kotlin.reflect.KFunction1
import kotlin.reflect.KProperty

interface Element :
  Key
  {
  val spec: Spec
  val parent: Container?
  val width: double
  val height: double
  val widthIndependent: double
  val heightIndependent: double
  val xPos: Pos
  val yPos: Pos
  val x: SubReact<Double>
  val y: SubReact<Double>

  fun dispatch(event: Event, handled: Boolean): Boolean

  interface Spec : InvokeAsRun {
    operator fun <T> get(key: String): T

    operator fun <T> get(key: KFunction1<T, *>): T = get(key.name)

    operator fun set(key: String, value: Any?)

    operator fun <T> set(key: KFunction1<T, *>, value: T) {
      set(key.name, value)
    }

    val specEntries: Collection<Pair<String, Any?>>

    fun init() {}

    val <T : Spec> T.set get() = this

    fun <T : Spec> T.put(key: String, value: Any?) = apply { set(key, value) }

    operator fun <T> getValue(self: Any?, prop: KProperty<*>): T = get(prop.name)

    fun <T : Spec> T.from(other: Spec) = apply {
      other.specEntries.forEach { [key, value] -> set(key, value) }
    }

    fun <T : Spec> T.from(other: Spec, vararg keys: String) = apply {
      keys.forEach { key -> set(key, other[key]) }
    }

    fun <T : Spec> T.from(other: Spec, vararg keys: KFunction1<*, *>) = apply {
      keys.forEach { key -> set(key.name, other[key.name]) }
    }
  }
}

fun <T : Element.Spec> T.initialized() = apply { init() }

infix fun <T : Element.Spec> T.key(it: Any?) = put("key", it)
infix fun <T : Element.Spec> T.k(it: Any?) = key(it)
infix fun <T : Element.Spec> T.tag(it: List<*>) = put("tag", it)
infix fun <T : Element.Spec> T.t(it: List<*>) = tag(it)
infix fun <T : Element.Spec> T.width(it: Dim) = put("width", it)
infix fun <T : Element.Spec> T.w(it: Dim) = width(it)
infix fun <T : Element.Spec> T.height(it: Dim) = put("height", it)
infix fun <T : Element.Spec> T.h(it: Dim) = height(it)
infix fun <T : Element.Spec> T.xPos(it: Pos) = put("xPos", it)
infix fun <T : Element.Spec> T.x(it: Pos) = xPos(it)
infix fun <T : Element.Spec> T.yPos(it: Pos) = put("yPos", it)
infix fun <T : Element.Spec> T.y(it: Pos) = yPos(it)

fun <T : Element.Spec> T.backend(it: Backend): Nothing {
  throw UnsupportedOperationException(
    "cannot set necron.layout.backend for components. this is a stub method for accessing the necron.layout.backend type-safely",
  )
}

fun <T : Element.Spec> T.parent(it: Container?): Nothing {
  throw UnsupportedOperationException(
    "cannot set parent for components. this is a stub method for accessing the parent type-safely",
  )
}

fun <T : Element.Spec> T.spec(it: KClass<out Element>): Nothing {
  throw UnsupportedOperationException(
    "cannot set spec for components. this is a stub method for accessing the spec type-safely",
  )
}

fun Element.selectLength(axis: Axis) = when (axis) {
  X -> width
  Y -> height
}

fun Element.selectLengthIndependent(axis: Axis) = when (axis) {
  X -> widthIndependent
  Y -> heightIndependent
}

fun Element.selectPos(axis: Axis) = when (axis) {
  X -> xPos
  Y -> yPos
}

fun Element.selectPosition(axis: Axis) = when (axis) {
  X -> x
  Y -> y
}
