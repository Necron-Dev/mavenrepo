package necron.layout.widget

import necron.layout.backend.Backend
import necron.layout.react.*
import necron.layout.style.Style
import necron.layout.style.emptyStyle
import kotlin.reflect.KProperty

sealed interface ChildrenDsl<out T : Container?> {
  val parent: T

  fun add(key: Any?, construct: (Any?) -> Element)

  operator fun <T> React<T>.provideDelegate(self: Any?, prop: KProperty<*>): React<T> {
    listen(this)
    return this
  }

  operator fun <T> MutReact<T>.provideDelegate(self: Any?, prop: KProperty<*>): MutReact<T> {
    listen(this)
    return this
  }

  operator fun <T> React<T>.invoke(): T {
    listen(this)
    return get()
  }

  fun listen(vararg reacts: React<*>)
}

private class ChildrenDslImpl<out T : Container?>(
  override val parent: T,
  private val children: MutableList<KeyConstructor<Element>>,
  private val dependencies: MutableSet<React<*>>,
) : ChildrenDsl<T> {
  override fun add(key: Any?, construct: (Any?) -> Element) {
    children += KeyConstructor(key, construct)
  }

  override fun listen(vararg reacts: React<*>) {
    dependencies += reacts
  }
}

fun <T : Container?> createChildren(
  backend: Backend,
  parent: T,
  style: Style = emptyStyle,
  fn: Children<T>,
): CalcListReact<Element> {
  var lastDependencies = mutableSetOf<React<*>>()
  var calcList: CalcListReact<Element>? = null
  calcList = useCalcList {
    val children = mutableListOf<KeyConstructor<Element>>()
    val dependencies = mutableSetOf<React<*>>()
    context(backend, style) {
      ChildrenDslImpl(parent, children, dependencies).fn()
    }
    calcList?.apply {
      unhook(lastDependencies - dependencies)
      hook(dependencies - lastDependencies)
    }
    lastDependencies = dependencies
    children
  }.hook(lastDependencies)
  return calcList
}

typealias Children<T> =
  context(Backend, Style)
  ChildrenDsl<T>.() -> Unit

val emptyChildren: Children<*> = {}
