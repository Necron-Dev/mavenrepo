package necron.layout.widget

open class MapSpec : Element.Spec {
  val map: Map<String, Any?>
    field = mutableMapOf<String, Any?>()

  @Suppress("UNCHECKED_CAST")
  override fun <T> get(key: String) = map[key] as T

  override fun set(key: String, value: Any?) {
    map[key] = value
  }

  override val specEntries get() = map.entries.map { it.key to it.value }
}
