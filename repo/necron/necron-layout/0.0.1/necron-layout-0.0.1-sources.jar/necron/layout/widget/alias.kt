package necron.layout.widget

import necron.layout.event.Event

typealias EventHandler = (Event, Boolean) -> Boolean
