package necron.layout.widget

import necron.layout.event.Event
import necron.layout.layout.Axis
import necron.layout.react.ListReact
import necron.layout.react.double
import necron.layout.react.invoke
import necron.layout.style.Style
import necron.layout.vector.Transformable
import necron.layout.vector.vec
import necron.layout.widget.Container.Spec

interface Container : Element {
  val children: ListReact<Element>
  val xSpace: double
  val ySpace: double

  override fun dispatch(event: Event, handled: Boolean): Boolean {
    var handled = handled
    children().forEach { child ->
      handled = handled or child.dispatch(
        when (event) {
          is Transformable<*> ->
            event
              .translate(-child.x() vec -child.y())
              as? Event
              ?: return@forEach

          else -> event
        },
        handled,
      )
    }
    return handled
  }

  interface Spec<C : Container?> : Element.Spec {
    override fun init() {
      set children emptyChildren
    }
  }
}

infix fun <T : Spec<C>, C : Container?> T.children(it: Children<C>) = put("children", it)
infix fun <T : Spec<C>, C : Container?> T.c(it: Children<C>) = children(it)
infix fun <T : Spec<C>, C : Container?> T.style(it: Style) = put("style", it)
infix fun <T : Spec<C>, C : Container?> T.s(it: Style) = style(it)

fun Container.selectSpace(axis: Axis) = when (axis) {
  X -> xSpace
  Y -> ySpace
}
