package necron.layout.widget.element

import necron.layout.backend.Backend
import necron.layout.event.Event
import necron.layout.event.RenderEvent
import necron.layout.layout.Axis
import necron.layout.layout.Dim
import necron.layout.layout.Pos
import necron.layout.react.*
import necron.layout.render.debug.DebugRectRenderable
import necron.layout.util.provider
import necron.layout.vector.vec
import necron.layout.vector.zeroVec
import necron.layout.widget.*

class Node private constructor(
  override val spec: Element.Spec,
  override val key: Any?,
  override val parent: Container?,
  val backend: Backend,
  private val eventHandler: React<EventHandler>?,
  override val width: double,
  override val height: double,
  override val widthIndependent: double,
  override val heightIndependent: double,
  override val xPos: Pos,
  override val yPos: Pos,
) : Element {
  override val x = zero.sub
  override val y = zero.sub

  constructor(
    spec: Element.Spec,
    key: Any?,
    parent: Container?,
    backend: Backend,
    eventHandler: React<EventHandler>?,
    width: Dim,
    height: Dim,
    xPos: Pos,
    yPos: Pos,
  ) : this(
    spec,
    key,
    parent,
    backend,
    eventHandler,
    createDim(parent, Axis.X, width),
    createDim(parent, Axis.Y, height),
    createDimIndependent(width),
    createDimIndependent(height),
    xPos,
    yPos,
  )

  override fun dispatch(event: Event, handled: Boolean): Boolean {
    when (event) {
      is RenderEvent -> {
        if (backend.debugMode) {
          event(
            DebugRectRenderable(
              DebugRectRenderable.Type.Outer,
              zeroVec,
              width() vec height(),
            ),
          )
        }
      }
    }

    return eventHandler?.get()?.invoke(event, handled) ?: handled
  }

  interface Spec : Element.Spec {
    override fun init() {
      set eventHandler null
    }
  }

  class Config :
    MapSpec(),
    Spec

  companion object : ElementDsl<ChildrenDsl<*>, Spec>(Spec::class, ::Config) {
    private fun createDim(
      parent: Container?,
      axis: Axis,
      dim: Dim,
      minimum: () -> double = zero.provider,
    ) = dim.create(
      minimum,
      lazy { parent!!.selectSpace(axis) }::value,
      lazy { parent!!.selectLength(axis) }::value,
    )

    private fun createDimIndependent(dim: Dim) = dim.create(zero.provider)

    override fun new(spec: Spec) = Node(
      spec,
      spec[spec::key],
      spec[spec::parent],
      spec[spec::backend],
      spec[spec::eventHandler],
      spec[spec::width],
      spec[spec::height],
      spec[spec::xPos],
      spec[spec::yPos],
    )

    fun new(
      spec: Spec,
      xMinimum: () -> double,
      yMinimum: () -> double,
      xIndependent: double,
      yIndependent: double,
    ) = Node(
      spec,
      spec[spec::key],
      spec[spec::parent],
      spec[spec::backend],
      spec[spec::eventHandler],
      createDim(spec[spec::parent], Axis.X, spec[spec::width], xMinimum),
      createDim(spec[spec::parent], Axis.Y, spec[spec::height], yMinimum),
      xIndependent,
      yIndependent,
      spec[spec::xPos],
      spec[spec::yPos],
    )
  }
}

infix fun <T : Node.Spec> T.eventHandler(it: React<EventHandler>?) = put("eventHandler", it)
infix fun <T : Node.Spec> T.e(it: React<EventHandler>?) = eventHandler(it)
