package necron.layout.animation

import kotlin.math.*

fun interface Ease {
  fun ease(progress: Double): Double

  val out get() = ease { 1.0 - ease(1.0 - it) }

  val inOut
    get() = ease {
      if (it < 0.5) ease(it + it) * 0.5 else 1.0 - ease(2.0 - it - it) * 0.5
    }
}

inline fun ease(crossinline fn: (Double) -> Double) = Ease { fn(it) }

inline fun normEase(crossinline fn: (Double) -> Double): Ease {
  val at0 = fn(0.0)
  val diff = fn(1.0) - at0
  return ease { (fn(it) - at0) / diff }
}

inline val Ease.cached
  get() = object : Ease {
    override fun ease(progress: Double) = this@cached.ease(progress)

    override val out = super.out

    override val inOut = super.inOut
  }

data object Linear : Ease by (normEase { it }.cached)

data object Quad : Ease by (normEase { it * it }.cached)

data object Cubic : Ease by (normEase { it * it * it }.cached)

data object Quart : Ease by (normEase { it * it * it * it }.cached)

data object Quint : Ease by (normEase { it * it * it * it * it }.cached)

data object Sine : Ease by (normEase { 1.0 - cos(PI * 0.5 * it) }.cached)

data object Expo : Ease by (normEase { 2.0.pow(10.0 * it - 10.0) }.cached)

data object Circ : Ease by (normEase { 1.0 - sqrt(1.0 - it * it) }.cached)

data object Back : Ease by (normEase { (2.70158 * it - 1.70158) * it * it }.cached)

data object Elastic : Ease by normEase({
  2.0.pow(10.0 * it - 10.0) * -sin(PI * 2.0 / 3.0 * (10.0 * it - 10.75))
}).cached
