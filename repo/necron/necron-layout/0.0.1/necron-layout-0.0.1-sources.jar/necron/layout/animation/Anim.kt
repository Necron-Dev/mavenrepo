package necron.layout.animation

import necron.layout.react.*
import necron.layout.util.InvokeAsApply
import kotlin.math.max

private data class EaseAction(
  val ease: Ease,
  val magnitude: Double,
  val duration: Long,
  val start: Long,
)

interface AnimChain : InvokeAsApply {
  fun next(ease: Ease, target: Double, duration: Double, start: Double = 0.0): AnimChain

  val await: AnimChain

  fun sleep(waitDuration: Double): AnimChain {
    return object : AnimChain {
      override fun next(ease: Ease, target: Double, duration: Double, start: Double): AnimChain {
        return this@AnimChain.next(
          ease,
          target,
          duration,
          waitDuration + start,
        )
      }

      override val await get() = this
    }
  }
}

class Anim(private var base: Double) :
  BaseReact<Double>(base),
  MutReact<Double>,
  AnimChain {
  private var update = false

  private val actions = ArrayDeque<EaseAction>()

  val completed get() = actions.isEmpty()

  val target get() = base

  override fun set(value: Double) {
    base = value
    actions.clear()
    unhook(NanoTime)
    update = true
  }

  fun teleport(value: Double) = apply { set(value) }

  fun nextAbsolute(ease: Ease, target: Double, duration: Double, start: Long): AnimChain {
    val durationNs = max(0, (duration * 1_000_000_000).toLong())
    if (durationNs > 0) {
      actions += EaseAction(
        ease,
        target - base,
        durationNs,
        start,
      )
      hook(NanoTime)
    }
    base = target
    val nextStart = start
    return object : AnimChain {
      override fun next(ease: Ease, target: Double, duration: Double, start: Double): AnimChain {
        return nextAbsolute(
          ease,
          target,
          duration,
          nextStart + (start * 1_000_000_000).toLong(),
        )
      }

      override val await = sleep(duration)
    }
  }

  override fun next(ease: Ease, target: Double, duration: Double, start: Double): AnimChain {
    return nextAbsolute(ease, target, duration, NanoTime() + (start * 1_000_000_000).toLong())
  }

  override val await get() = this

  fun anim(ease: Ease, target: Double, duration: Double, start: Double = 0.0): AnimChain {
    return interrupt().next(ease, target, duration, start)
  }

  fun interrupt() = teleport(get())

  fun complete() = teleport(base)

  override fun update(updating: Boolean, serial: Long, setter: (Double) -> Unit) {
    if (!updating && !update) return
    val last = get()
    when {
      actions.isNotEmpty() -> {
        val time = NanoTime()
        actions.removeAll { time - it.start > it.duration }
        if (actions.isEmpty()) {
          unhook(NanoTime)
          if (last != base) setter(base)
        } else {
          var value = base
          actions.forEach {
            if (time < it.start) {
              value -= it.magnitude
            } else {
              val progress = (time - it.start).toDouble() / it.duration
              value -= it.magnitude * (1.0 - it.ease.ease(progress))
            }
          }
          if (last != value) setter(value)
        }
      }

      update && last != base -> setter(base)
    }
    update = false
  }
}
