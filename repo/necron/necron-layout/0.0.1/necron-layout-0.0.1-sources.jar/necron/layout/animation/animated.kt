package necron.layout.animation

import necron.layout.color.argb
import necron.layout.color.color
import necron.layout.react.*

inline fun double.animated(crossinline animate: Anim.(Double) -> Unit): Anim {
  val anim = Anim(this())
  return anim.hook(listen { anim.animate(it) })
}

inline fun double.animated(
  crossinline animateUp: Anim.(Double) -> Unit,
  crossinline animateDown: Anim.(Double) -> Unit,
): Anim {
  val anim = Anim(this())
  return anim.hook(
    listen { old, new ->
      if (new >= old) anim.animateUp(new) else anim.animateDown(new)
    },
  )
}

inline fun color.gradient(crossinline animate: Anim.(Double) -> Unit): color {
  val a = calc { it.a }.animated(animate)
  val r = calc { it.r }.animated(animate)
  val g = calc { it.g }.animated(animate)
  val b = calc { it.b }.animated(animate)
  return useAuto { argb(a(), r(), g(), b()) }
}

inline fun color.gradient(
  crossinline animateUp: Anim.(Double) -> Unit,
  crossinline animateDown: Anim.(Double) -> Unit,
): color {
  val a = calc { it.a }.animated(animateUp, animateDown)
  val r = calc { it.r }.animated(animateUp, animateDown)
  val g = calc { it.g }.animated(animateUp, animateDown)
  val b = calc { it.b }.animated(animateUp, animateDown)
  return useAuto { argb(a(), r(), g(), b()) }
}
