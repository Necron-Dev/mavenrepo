package necron.layout.event

import necron.layout.render.Renderable
import necron.layout.vector.Transformable
import necron.layout.vector.Vec
import necron.layout.vector.unaryMinus

class RenderEvent(private val emit: (Renderable<*>) -> Unit) :
  Event,
  Transformable<RenderEvent> {
  override val self get() = this

  operator fun invoke(renderable: Renderable<*>) {
    emit(renderable)
  }

  override fun translate(vec: Vec) = RenderEvent {
    emit(it.translate(-vec))
  }

  override fun scale(origin: Vec, factor: Double) = RenderEvent {
    emit(it.scale(origin, 1.0 / factor))
  }
}
