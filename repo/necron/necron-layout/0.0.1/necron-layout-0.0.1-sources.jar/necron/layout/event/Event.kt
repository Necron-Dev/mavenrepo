package necron.layout.event

interface Event
