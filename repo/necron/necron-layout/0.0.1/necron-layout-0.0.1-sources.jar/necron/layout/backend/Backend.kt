package necron.layout.backend

interface Backend {
  val debugMode: Boolean
}
