package necron.layout.style

import necron.layout.widget.*
import kotlin.reflect.KClass
import kotlin.reflect.safeCast

class StyleSheetDsl(
  private val negative: MutableList<Style.Entry>,
  private val positive: MutableList<Style.Entry>,
) {
  data class CssWithPriority<in T : Element.Spec>(val priority: Int, val fn: T.() -> Unit)

  inner class Selector<out T : Element.Spec>(
    private val onAppend: () -> Unit = {},
    private val matcher: (Element.Spec) -> T?,
  ) {
    fun match(spec: Element.Spec) = matcher(spec)

    operator fun get(vararg tags: Any?) = Selector { spec ->
      match(spec)?.takeIf { it[it::tag].containsAll(tags.asList()) }
    }

    operator fun invoke(key: Any?) = Selector { spec ->
      match(spec)?.takeIf { it[it::key] == key }
    }

    fun where(predicate: T.() -> Boolean) = Selector { spec ->
      match(spec)?.takeIf { predicate(it) }
    }

    operator fun <S : Element.Spec> times(child: Selector<S>) = Selector { spec ->
      child.match(spec)?.takeIf {
        var parent = it[it::parent]?.spec
        while (parent != null) {
          if (match(parent) != null) return@takeIf true
          parent = it[it::parent]?.spec
        }
        false
      }
    }

    operator fun <S : Element.Spec> div(child: Selector<S>) = Selector { spec ->
      child.match(spec)?.takeIf {
        val parent = it[it::parent]
        parent != null && match(parent.spec) != null
      }
    }

    operator fun minus(cssWithPriority: CssWithPriority<T>) {
      val collection = when {
        cssWithPriority.priority > 0 -> positive
        cssWithPriority.priority < 0 -> negative
        else -> throw IllegalArgumentException("css priority cannot be zero")
      }
      collection += Style.Entry(cssWithPriority.priority) {
        match(it)?.let(cssWithPriority.fn)
      }
      onAppend()
    }

    operator fun minus(fn: T.() -> Unit) = minus(CssWithPriority(1, fn))
  }

  fun <T : Element.Spec> typed(type: KClass<out T>) = Selector { type.safeCast(it) }

  fun <T : Element.Spec> exact(type: KClass<out T>) = Selector { spec ->
    type.safeCast(spec)?.takeIf { it::class == type }
  }

  inline fun <reified T : Element.Spec> typed() = typed(T::class)

  inline fun <reified T : Element.Spec> exact() = exact(T::class)

  fun <T : Element.Spec> typed(dsl: ElementDsl<*, T>) = typed(dsl.type)

  fun <T : Element.Spec> exact(dsl: ElementDsl<*, T>) = exact(dsl.constructSpec()::class)

  val any get() = Selector { it }

  operator fun <T : Element.Spec> Int.invoke(fn: T.() -> Unit) = CssWithPriority(this, fn)
}

inline fun css(builder: StyleSheetDsl.() -> Unit): Style {
  val negative = mutableListOf<Style.Entry>()
  val positive = mutableListOf<Style.Entry>()
  StyleSheetDsl(negative, positive).builder()
  negative.sort()
  positive.sort()
  return Style(negative, positive)
}
