package necron.layout.style

import necron.layout.widget.Element

data class Style(val pre: List<Entry>, val post: List<Entry>) {
  data class Entry(val priority: Int, val transform: (Element.Spec) -> Unit) : Comparable<Entry> {
    override fun compareTo(other: Entry) = priority compareTo other.priority
  }

  context(style: Style)
  operator fun invoke(fn: context(Style) () -> Unit) {
    val combined = style + this
    context(combined) { fn() }
  }

  operator fun plus(style: Style) = Style(
    (this.pre + style.pre).sorted(),
    (this.post + style.post).sorted(),
  )
}

val emptyStyle = Style([], [])
